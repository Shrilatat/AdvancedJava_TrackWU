package com.wu.db;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class DBDemo {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("dbconfig.xml");
        JdbcTemplate jt = ctx.getBean("jdbcTemplate", JdbcTemplate.class);

      /* int count = jt.queryForObject("select count(*) from emp", Integer.class);
        System.out.println(count);

        //scanner

        String empName = jt.queryForObject("select ename from emp where empid=?", String.class, 104);
        System.out.println(empName);

        String sql = "insert into emp values(999,'Mamendra',45000,'ASE')";
        jt.update(sql);*/

        List<Integer> depts = jt.queryForList("select deptno from dept", Integer.class);
        System.out.println(depts);

    }
}
