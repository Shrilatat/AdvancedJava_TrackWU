package com.wu.db;

public class Emp {
    int empid;
    String ename, desig;
    double sal;

    public Emp(){}

    public Emp(int empid, String ename, String desig, double sal) {
        this.empid = empid;
        this.ename = ename;
        this.desig = desig;
        this.sal = sal;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "empid=" + empid +
                ", ename='" + ename + '\'' +
                ", desig='" + desig + '\'' +
                ", sal=" + sal +
                '}';
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getDesig() {
        return desig;
    }

    public void setDesig(String desig) {
        this.desig = desig;
    }

    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }


}
