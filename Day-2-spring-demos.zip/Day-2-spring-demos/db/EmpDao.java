package com.wu.db;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmpDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public void addEmp(){

    }

    public void deleteEmpById(int id){

    }

    public List<Emp> getAllEmps(){
         return null;
    }

    public Emp getEmpById(int id){
         return null;
    }

}
