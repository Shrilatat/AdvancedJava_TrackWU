package com.wu.db;


import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpMapper implements RowMapper<Emp> {
    @Override
    public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
        Emp e1 = new Emp(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4));
        return e1;
    }
}

