package com.wu.db;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpExtractor implements ResultSetExtractor<Emp> {

    @Override
    public Emp extractData(ResultSet rs) throws SQLException, DataAccessException {
        Emp e = new Emp();
        return e;
    }
}
