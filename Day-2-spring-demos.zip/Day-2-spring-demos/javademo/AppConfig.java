package com.wu.javademo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    //<bean id="b1" class="com.trg.Helloworld" />

    @Bean
    public HelloWorld m1(){
        return new HelloWorld();
    }
}
