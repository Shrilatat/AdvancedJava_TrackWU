package com.wu.javademo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class HWClientApp {
    public static void main(String[] args) {
        ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        HelloWorld hw = ctx.getBean("m1", HelloWorld.class);
        hw.sayHello();

    }
}
