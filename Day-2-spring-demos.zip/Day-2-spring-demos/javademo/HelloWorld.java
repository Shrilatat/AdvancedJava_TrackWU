package com.wu.javademo;

import org.springframework.stereotype.Component;

public class HelloWorld {
    public void sayHello(){
        System.out.println("Hello Spring!");
    }

}
