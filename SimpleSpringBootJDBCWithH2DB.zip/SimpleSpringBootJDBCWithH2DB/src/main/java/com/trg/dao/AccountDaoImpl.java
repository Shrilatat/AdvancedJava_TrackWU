package com.trg.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trg.model.Account;

@Repository
public class AccountDaoImpl implements AccountDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int save(Account ac) {
		String sql = "insert into accounts values(?,?,?,?)";
		return jdbcTemplate.update(sql,
				ac.getAcctId(), ac.getAname(), ac.getType(), ac.getBal());
	}

	public int update(Account ac) {
		String sql = "update accounts set bal = ? where acctid = ?";
		return jdbcTemplate.update(sql, ac.getBal(), ac.getAcctId());
	}

	public int deleteById(int id) {
		String sql = "delete from accounts where acctid = ?";
		return jdbcTemplate.update(sql, id);
	}

	public List<Account> findAll() {
		String sql = "select * from accounts";
		return jdbcTemplate.query(sql, (rs, rowno) -> new Account(
				rs.getInt("acctid"), rs.getString("aname"), 
				rs.getString("type"), rs.getDouble("bal")));
	}

	public int count() {
		String sql = "select count(*) from accounts";
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

	@Override
	public String getNameById(int id) {
		String sql = "select * from accounts where acctid=?";
		Account ac = jdbcTemplate.queryForObject(sql , new Object[] {id}, (rs, rowNum) -> new Account(rs.getInt("acctid"),
				rs.getString("aname"), rs.getString("type"), rs.getDouble("bal")));
		return ac.getAname();
	}

	@Override
	public List<Account> findByName(String name) {
		String sql = "select * from accounts where aname=?";
		List<Account> list = jdbcTemplate.query(sql , new Object[] {name}, (rs, rowNum) -> new Account(rs.getInt("acctid"),
				rs.getString("aname"), rs.getString("type"), rs.getDouble("bal")));
		return list;
	}

}
