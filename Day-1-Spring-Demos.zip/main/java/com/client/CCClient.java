package com.client;

import com.trg.beans.CurrencyConverter;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CCClient {
    public static void main(String[] args) {
        //CurrencyConverter cc = new CurrencyConverter(80.4);
        //System.out.println(cc.dollarsToRs(100));

        ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
        CurrencyConverter cc = ctx.getBean("cc",CurrencyConverter.class);
        System.out.println(cc.dollarsToRs(100));
    }
}
