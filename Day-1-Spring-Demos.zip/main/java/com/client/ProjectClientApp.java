package com.client;

import com.trg.beans.Project;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProjectClientApp {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
        Project p = ctx.getBean("p1", Project.class);
        System.out.println(p.getEmpList());
    }
}
