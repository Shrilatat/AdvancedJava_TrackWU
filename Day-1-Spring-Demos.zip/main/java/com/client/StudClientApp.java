package com.client;

import com.trg.beans.HelloWorld;
import com.trg.beans.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudClientApp {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
        Student s = ctx.getBean("s1",Student.class);
        System.out.println(s);
    }
}
