package com.client;

import com.trg.beans.HelloWorld;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApp {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
        HelloWorld hw = ctx.getBean("b1", HelloWorld.class);
        hw.sayHello();

    }
}
