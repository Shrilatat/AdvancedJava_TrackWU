package com.trg.beans;

import org.springframework.stereotype.Component;

@Component("es")
public class ExchangeService {
    public double getExchangeRate(){
        //code complex
        return 71.0;
    }
}
