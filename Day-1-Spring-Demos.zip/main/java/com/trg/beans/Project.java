package com.trg.beans;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
@Component
public class Project {
   List<Emp> empList;

    public List<Emp> getEmpList() {
        return empList;
    }

    public void setEmpList(List<Emp> empList) {
        this.empList = empList;
    }
}
