package com.trg.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("cc")
public class CurrencyConverter {


    @Autowired
     ExchangeService exchangeService;

    public void setExchangeService(ExchangeService exchangeService) {
        this.exchangeService = exchangeService;
    }

    public double dollarsToRs(int amount){
        return amount * exchangeService.getExchangeRate();
    }
}
