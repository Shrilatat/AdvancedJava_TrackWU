package com.trg.beans;

import org.springframework.stereotype.Component;

@Component("b1")
public class HelloWorld {

    public void sayHello(){
        System.out.println("Hello Spring!");
    }

}
